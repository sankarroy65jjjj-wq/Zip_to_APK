package com.example.midi

import android.content.Context
import android.content.pm.PackageManager
import android.media.midi.MidiDevice
import android.media.midi.MidiDeviceInfo
import android.media.midi.MidiManager
import android.media.midi.MidiOutputPort
import android.media.midi.MidiReceiver
import android.os.Handler
import android.os.Looper
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class MidiStatus(
    val isSupported: Boolean,
    val connectedDeviceCount: Int,
    val connectedDeviceNames: List<String>,
    val lastReceivedNote: Int? = null,
    val lastReceivedVelocity: Int? = null,
    val statusMessage: String
)

class MidiController(
    private val context: Context,
    private val onMidiNoteTrigger: (noteNumber: Int, velocity: Float) -> Unit
) {

    private val midiManager: MidiManager? = if (context.packageManager.hasSystemFeature(PackageManager.FEATURE_MIDI)) {
        context.getSystemService(Context.MIDI_SERVICE) as? MidiManager
    } else {
        null
    }

    private val _status = MutableStateFlow(
        MidiStatus(
            isSupported = midiManager != null,
            connectedDeviceCount = 0,
            connectedDeviceNames = emptyList(),
            statusMessage = if (midiManager != null) "MIDI Engine Ready (No devices connected)" else "MIDI not supported on this device"
        )
    )
    val status: StateFlow<MidiStatus> = _status.asStateFlow()

    private val openDevices = mutableListOf<MidiDevice>()
    private val openPorts = mutableListOf<MidiOutputPort>()
    private val handler = Handler(Looper.getMainLooper())

    private val deviceCallback = object : MidiManager.DeviceCallback() {
        override fun onDeviceAdded(device: MidiDeviceInfo?) {
            refreshDevices()
        }

        override fun onDeviceRemoved(device: MidiDeviceInfo?) {
            refreshDevices()
        }

        override fun onDeviceStatusChanged(status: android.media.midi.MidiDeviceStatus?) {
            refreshDevices()
        }
    }

    init {
        midiManager?.let { manager ->
            manager.registerDeviceCallback(deviceCallback, handler)
            refreshDevices()
        }
    }

    fun refreshDevices() {
        val manager = midiManager ?: return
        val devices = manager.devices
        val deviceNames = mutableListOf<String>()

        // Close old connections
        closeAllConnections()

        for (info in devices) {
            val name = info.properties.getString(MidiDeviceInfo.PROPERTY_NAME)
                ?: info.properties.getString(MidiDeviceInfo.PROPERTY_PRODUCT)
                ?: "USB MIDI Device #${info.id}"
            deviceNames.add(name)

            // Connect to output ports (MIDI source from controller to app)
            manager.openDevice(info, { device ->
                if (device != null) {
                    openDevices.add(device)
                    // Search for output ports
                    val portCount = info.outputPortCount
                    for (portIndex in 0 until portCount) {
                        try {
                            val outputPort = device.openOutputPort(portIndex)
                            if (outputPort != null) {
                                openPorts.add(outputPort)
                                outputPort.connect(object : MidiReceiver() {
                                    override fun onSend(msg: ByteArray, offset: Int, count: Int, timestamp: Long) {
                                        parseMidiData(msg, offset, count)
                                    }
                                })
                            }
                        } catch (e: Exception) {
                            e.printStackTrace()
                        }
                    }
                }
            }, handler)
        }

        val msg = if (devices.isNotEmpty()) {
            "Connected to ${devices.size} MIDI device(s): ${deviceNames.joinToString()}"
        } else {
            "Ready. Connect a USB MIDI controller or trigger pad via OTG"
        }

        _status.value = _status.value.copy(
            connectedDeviceCount = devices.size,
            connectedDeviceNames = deviceNames,
            statusMessage = msg
        )
    }

    private fun parseMidiData(msg: ByteArray, offset: Int, count: Int) {
        var idx = offset
        val end = offset + count
        while (idx < end) {
            val byteVal = msg[idx].toInt() and 0xFF
            // Note On message: 0x90 to 0x9F (channels 1-16)
            if (byteVal in 0x90..0x9F && idx + 2 < end) {
                val noteNumber = msg[idx + 1].toInt() and 0x7F
                val velocityInt = msg[idx + 2].toInt() and 0x7F
                if (velocityInt > 0) {
                    val velocityFloat = velocityInt / 127.0f
                    handler.post {
                        _status.value = _status.value.copy(
                            lastReceivedNote = noteNumber,
                            lastReceivedVelocity = velocityInt
                        )
                        onMidiNoteTrigger(noteNumber, velocityFloat)
                    }
                }
                idx += 3
            } else {
                idx++
            }
        }
    }

    private fun closeAllConnections() {
        openPorts.forEach {
            try { it.close() } catch (_: Exception) {}
        }
        openPorts.clear()

        openDevices.forEach {
            try { it.close() } catch (_: Exception) {}
        }
        openDevices.clear()
    }

    fun release() {
        midiManager?.unregisterDeviceCallback(deviceCallback)
        closeAllConnections()
    }
}
