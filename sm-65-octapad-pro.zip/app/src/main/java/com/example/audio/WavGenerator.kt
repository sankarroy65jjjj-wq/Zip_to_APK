package com.example.audio

import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin
import kotlin.random.Random

object WavGenerator {

    private const val SAMPLE_RATE = 44100

    fun writeWavFile(file: File, samples: ShortArray) {
        val totalAudioLen = samples.size * 2
        val totalDataLen = totalAudioLen + 36
        val channels = 1
        val byteRate = SAMPLE_RATE * channels * 2

        val header = ByteArray(44)
        val buffer = ByteBuffer.wrap(header).order(ByteOrder.LITTLE_ENDIAN)

        // RIFF header
        buffer.put("RIFF".toByteArray())
        buffer.putInt(totalDataLen)
        buffer.put("WAVE".toByteArray())

        // fmt chunk
        buffer.put("fmt ".toByteArray())
        buffer.putInt(16) // Subchunk1Size (16 for PCM)
        buffer.putShort(1) // AudioFormat (1 for PCM)
        buffer.putShort(channels.toShort())
        buffer.putInt(SAMPLE_RATE)
        buffer.putInt(byteRate)
        buffer.putShort((channels * 2).toShort()) // BlockAlign
        buffer.putShort(16) // BitsPerSample

        // data chunk
        buffer.put("data".toByteArray())
        buffer.putInt(totalAudioLen)

        FileOutputStream(file).use { out ->
            out.write(header)
            val byteBuf = ByteBuffer.allocate(samples.size * 2).order(ByteOrder.LITTLE_ENDIAN)
            for (sample in samples) {
                byteBuf.putShort(sample)
            }
            out.write(byteBuf.array())
        }
    }

    fun generatePercussionSample(soundId: String): ShortArray {
        val durationSec = when (soundId) {
            "crash_cymbal" -> 1.2
            "ride_bell" -> 0.9
            "sub_808" -> 0.8
            "hihat_open" -> 0.6
            "kick_acoustic", "tom_low", "conga_low", "tabla_bayan" -> 0.45
            else -> 0.3
        }

        val totalSamples = (SAMPLE_RATE * durationSec).toInt()
        val result = ShortArray(totalSamples)
        val raw = DoubleArray(totalSamples)
        val rand = Random(42)
        var maxPeak = 0.0

        for (i in 0 until totalSamples) {
            val t = i.toDouble() / SAMPLE_RATE
            val sampleVal: Double = when (soundId) {
                "kick_acoustic" -> {
                    // Fast pitch drop from 150Hz to 48Hz + click
                    val freq = 48.0 + 102.0 * exp(-t * 28.0)
                    val phase = 2.0 * PI * (48.0 * t + (102.0 / 28.0) * (1.0 - exp(-t * 28.0)))
                    val body = sin(phase)
                    val click = if (t < 0.008) (rand.nextDouble() * 2.0 - 1.0) * (1.0 - t / 0.008) else 0.0
                    val env = exp(-t * 8.5)
                    (body * 0.85 + click * 0.4) * env
                }
                "sub_808" -> {
                    // Deep 808 boom at 46Hz with gentle saturation
                    val freq = 46.0 + 50.0 * exp(-t * 35.0)
                    val body = sin(2.0 * PI * freq * t)
                    val env = exp(-t * 3.8)
                    val sat = Math.tanh(body * 1.4)
                    sat * env
                }
                "snare_crisp" -> {
                    // 185Hz body + filtered white noise
                    val body = sin(2.0 * PI * 185.0 * t) * exp(-t * 18.0) * 0.5
                    val noise = (rand.nextDouble() * 2.0 - 1.0) * exp(-t * 12.0) * 0.65
                    val snap = if (t < 0.005) 0.6 * (1.0 - t / 0.005) else 0.0
                    (body + noise + snap)
                }
                "rim_shot" -> {
                    val tone = sin(2.0 * PI * 820.0 * t) * exp(-t * 40.0)
                    val click = (rand.nextDouble() * 2.0 - 1.0) * exp(-t * 80.0)
                    (tone * 0.7 + click * 0.5)
                }
                "hihat_closed" -> {
                    // Metallic cluster + noise, very short
                    val metallic = (sin(2.0 * PI * 4200.0 * t) + sin(2.0 * PI * 6500.0 * t) + sin(2.0 * PI * 9200.0 * t)) / 3.0
                    val noise = rand.nextDouble() * 2.0 - 1.0
                    val env = exp(-t * 55.0)
                    (metallic * 0.5 + noise * 0.5) * env
                }
                "hihat_open" -> {
                    val metallic = (sin(2.0 * PI * 3800.0 * t) + sin(2.0 * PI * 5900.0 * t) + sin(2.0 * PI * 8100.0 * t)) / 3.0
                    val noise = rand.nextDouble() * 2.0 - 1.0
                    val env = exp(-t * 7.5)
                    (metallic * 0.4 + noise * 0.6) * env
                }
                "tom_high" -> {
                    val freq = 120.0 + 80.0 * exp(-t * 16.0)
                    sin(2.0 * PI * freq * t) * exp(-t * 9.0)
                }
                "tom_mid" -> {
                    val freq = 90.0 + 60.0 * exp(-t * 14.0)
                    sin(2.0 * PI * freq * t) * exp(-t * 7.5)
                }
                "tom_low" -> {
                    val freq = 65.0 + 45.0 * exp(-t * 12.0)
                    sin(2.0 * PI * freq * t) * exp(-t * 6.0)
                }
                "crash_cymbal" -> {
                    val met = (sin(2.0 * PI * 2400.0 * t) + sin(2.0 * PI * 3950.0 * t) + sin(2.0 * PI * 5800.0 * t) + sin(2.0 * PI * 8900.0 * t)) / 4.0
                    val noise = rand.nextDouble() * 2.0 - 1.0
                    val env = exp(-t * 3.5)
                    (met * 0.35 + noise * 0.65) * env
                }
                "ride_bell" -> {
                    val bell = (sin(2.0 * PI * 1050.0 * t) + 0.6 * sin(2.0 * PI * 2100.0 * t) + 0.3 * sin(2.0 * PI * 3150.0 * t))
                    bell * exp(-t * 4.2) * 0.7
                }
                "hand_clap" -> {
                    // Triple flam impulses at 0, 11ms, 22ms then reverb burst
                    val flam = when {
                        t < 0.008 -> (rand.nextDouble() * 2.0 - 1.0) * 0.6
                        t in 0.011..0.019 -> (rand.nextDouble() * 2.0 - 1.0) * 0.7
                        t in 0.022..0.030 -> (rand.nextDouble() * 2.0 - 1.0) * 0.9
                        t > 0.030 -> (rand.nextDouble() * 2.0 - 1.0) * exp(-(t - 0.030) * 16.0) * 0.8
                        else -> 0.0
                    }
                    flam
                }
                "cowbell" -> {
                    // 587Hz & 845Hz classic cowbell
                    val tone = (sin(2.0 * PI * 587.0 * t) + 0.9 * sin(2.0 * PI * 845.0 * t)) * 0.5
                    val env = exp(-t * 18.0)
                    tone * env
                }
                "conga_high" -> {
                    val freq = 290.0 + 40.0 * exp(-t * 30.0)
                    val slap = if (t < 0.006) (rand.nextDouble() * 2.0 - 1.0) * 0.4 else 0.0
                    (sin(2.0 * PI * freq * t) * 0.7 + slap) * exp(-t * 12.0)
                }
                "conga_low" -> {
                    val freq = 160.0 + 30.0 * exp(-t * 22.0)
                    sin(2.0 * PI * freq * t) * exp(-t * 8.0) * 0.9
                }
                "bongo" -> {
                    val freq = 380.0 + 80.0 * exp(-t * 35.0)
                    val slap = if (t < 0.005) (rand.nextDouble() * 2.0 - 1.0) * 0.5 else 0.0
                    (sin(2.0 * PI * freq * t) * 0.7 + slap) * exp(-t * 16.0)
                }
                "shaker" -> {
                    val noise = rand.nextDouble() * 2.0 - 1.0
                    val env = if (t < 0.04) (t / 0.04) else exp(-(t - 0.04) * 22.0)
                    noise * env * 0.8
                }
                "tabla_dayan" -> {
                    // Resonant tuned Indian tabla head (treble rim ring at 340Hz with harmonic at 680Hz)
                    val tone = (sin(2.0 * PI * 340.0 * t) + 0.4 * sin(2.0 * PI * 680.0 * t)) * 0.7
                    val click = if (t < 0.006) 0.5 * (1.0 - t / 0.006) else 0.0
                    (tone + click) * exp(-t * 8.0)
                }
                "tabla_bayan" -> {
                    // Characteristic upward-then-downward pitch bend (Dagga ge- sound)
                    val bend = sin(2.0 * PI * 6.0 * t) * 35.0
                    val freq = 65.0 + bend
                    sin(2.0 * PI * freq * t) * exp(-t * 6.5) * 0.9
                }
                "dholak_bass" -> {
                    // Deep Punjabi dholak low thump with warmth
                    val freq = 75.0 + 55.0 * exp(-t * 25.0)
                    sin(2.0 * PI * freq * t) * exp(-t * 9.0) * 0.95
                }
                "dholak_treble" -> {
                    // Sharp high crisp dholak "ta"
                    val freq = 560.0 + 80.0 * exp(-t * 30.0)
                    val crack = (rand.nextDouble() * 2.0 - 1.0) * 0.4 * exp(-t * 35.0)
                    (sin(2.0 * PI * freq * t) * 0.65 + crack) * exp(-t * 14.0)
                }
                "tambourine" -> {
                    val hit = if (t < 0.006) (rand.nextDouble() * 2.0 - 1.0) * 0.6 else 0.0
                    val jingles = (sin(2.0 * PI * 5200.0 * t) + sin(2.0 * PI * 8100.0 * t) + (rand.nextDouble() * 2.0 - 1.0) * 0.6) * 0.4
                    (hit + jingles) * exp(-t * 11.0)
                }
                else -> {
                    sin(2.0 * PI * 440.0 * t) * exp(-t * 10.0)
                }
            }

            raw[i] = sampleVal
            val absVal = kotlin.math.abs(sampleVal)
            if (absVal > maxPeak) maxPeak = absVal
        }

        val normFactor = if (maxPeak > 0.001) 0.95 / maxPeak else 1.0
        for (i in 0 until totalSamples) {
            val clamped = (raw[i] * normFactor).coerceIn(-1.0, 1.0)
            result[i] = (clamped * 32767).toInt().toShort()
        }
        return result
    }
}
