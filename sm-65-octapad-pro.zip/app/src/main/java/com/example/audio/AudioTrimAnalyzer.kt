package com.example.audio

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sqrt

data class AudioAnalysisResult(
    val sampleRate: Int,
    val durationMs: Int,
    val detectedTrimStartMs: Int,
    val waveformPoints: FloatArray, // 100 normalized points for UI
    val noiseFloor: Float,
    val peakAmplitude: Float
)

object AudioTrimAnalyzer {

    suspend fun analyzeFile(file: File, threshold: Float = 0.05f): AudioAnalysisResult = withContext(Dispatchers.IO) {
        val (samples, sampleRate) = decodeToPcm(file)
        if (samples.isEmpty()) {
            return@withContext AudioAnalysisResult(
                sampleRate = 44100,
                durationMs = 0,
                detectedTrimStartMs = 0,
                waveformPoints = FloatArray(100) { 0f },
                noiseFloor = 0f,
                peakAmplitude = 0f
            )
        }

        val durationMs = ((samples.size.toLong() * 1000) / sampleRate).toInt()

        // 1. Calculate Peak and Initial Noise Floor
        var peak = 0f
        for (s in samples) {
            val a = abs(s)
            if (a > peak) peak = a
        }

        // Noise floor from first 20ms or 1000 samples
        val noiseSampleCount = (sampleRate * 0.02).toInt().coerceAtMost(samples.size)
        var noiseSum = 0.0
        for (i in 0 until noiseSampleCount) {
            noiseSum += abs(samples[i])
        }
        val noiseFloor = if (noiseSampleCount > 0) (noiseSum / noiseSampleCount).toFloat() else 0.01f

        // 2. Detect Attack Start Point
        // Look in 2ms windows
        val windowSize = (sampleRate * 0.002).toInt().coerceAtLeast(1)
        val detectionThreshold = max(threshold, noiseFloor * 1.5f).coerceAtMost(0.8f * peak)

        var detectedStartSample = 0
        var windowStart = 0
        while (windowStart + windowSize < samples.size) {
            var windowRms = 0.0
            for (i in windowStart until windowStart + windowSize) {
                windowRms += samples[i] * samples[i]
            }
            windowRms = sqrt(windowRms / windowSize)

            if (windowRms >= detectionThreshold) {
                // Confirm with subsequent window to avoid random pop
                val nextStart = windowStart + windowSize
                if (nextStart + windowSize < samples.size) {
                    var nextRms = 0.0
                    for (i in nextStart until nextStart + windowSize) {
                        nextRms += samples[i] * samples[i]
                    }
                    nextRms = sqrt(nextRms / windowSize)
                    if (nextRms >= detectionThreshold * 0.7f) {
                        detectedStartSample = windowStart
                        break
                    }
                } else {
                    detectedStartSample = windowStart
                    break
                }
            }
            windowStart += windowSize
        }

        val detectedTrimStartMs = ((detectedStartSample.toLong() * 1000) / sampleRate).toInt().coerceAtMost(durationMs)

        // 3. Downsample to 100 waveform points for UI Canvas
        val waveformPoints = FloatArray(100)
        val step = samples.size / 100.0
        val normFactor = if (peak > 0f) peak else 1f

        for (p in 0 until 100) {
            val startIdx = (p * step).toInt()
            val endIdx = ((p + 1) * step).toInt().coerceAtMost(samples.size)
            var maxVal = 0f
            for (i in startIdx until endIdx) {
                val a = abs(samples[i])
                if (a > maxVal) maxVal = a
            }
            waveformPoints[p] = (maxVal / normFactor).coerceIn(0f, 1f)
        }

        AudioAnalysisResult(
            sampleRate = sampleRate,
            durationMs = durationMs,
            detectedTrimStartMs = detectedTrimStartMs,
            waveformPoints = waveformPoints,
            noiseFloor = noiseFloor,
            peakAmplitude = peak
        )
    }

    suspend fun createTrimmedWav(
        context: Context,
        originalFile: File,
        trimStartMs: Int,
        padNumber: Int,
        patchNumber: Int
    ): File = withContext(Dispatchers.IO) {
        val (samples, sampleRate) = decodeToPcm(originalFile)
        val trimDir = File(context.cacheDir, "trimmed_sounds").apply { mkdirs() }
        val targetFile = File(trimDir, "pad_${patchNumber}_${padNumber}_trimmed.wav")

        if (trimStartMs <= 0 || samples.isEmpty()) {
            // No trim, render or return original
            val shortSamples = ShortArray(samples.size) { (samples[it] * 32767).toInt().toShort() }
            WavGenerator.writeWavFile(targetFile, shortSamples)
            return@withContext targetFile
        }

        val startSample = ((trimStartMs.toLong() * sampleRate) / 1000).toInt().coerceIn(0, samples.size - 1)
        val remainingLength = samples.size - startSample
        val shortSamples = ShortArray(remainingLength) {
            (samples[startSample + it] * 32767).toInt().toShort()
        }

        // Apply a gentle 1ms anti-click fade-in at attack start
        val fadeSamples = (sampleRate * 0.001).toInt().coerceAtMost(remainingLength)
        for (i in 0 until fadeSamples) {
            val gain = i.toFloat() / fadeSamples
            shortSamples[i] = (shortSamples[i] * gain).toInt().toShort()
        }

        WavGenerator.writeWavFile(targetFile, shortSamples)
        targetFile
    }

    fun decodeToPcm(file: File): Pair<FloatArray, Int> {
        return try {
            if (file.name.endsWith(".wav", ignoreCase = true)) {
                decodeWav(file)
            } else {
                decodeMediaCodec(file)
            }
        } catch (e: Exception) {
            e.printStackTrace()
            FloatArray(0) to 44100
        }
    }

    private fun decodeWav(file: File): Pair<FloatArray, Int> {
        FileInputStream(file).use { input ->
            val header = ByteArray(44)
            val read = input.read(header)
            if (read < 44) return FloatArray(0) to 44100

            val buf = ByteBuffer.wrap(header).order(ByteOrder.LITTLE_ENDIAN)
            val riff = String(header, 0, 4)
            if (riff != "RIFF") return decodeMediaCodec(file)

            val channels = buf.getShort(22).toInt()
            val sampleRate = buf.getInt(24)
            val bitsPerSample = buf.getShort(34).toInt()

            val rawBytes = input.readBytes()
            if (bitsPerSample == 16) {
                val shortCount = rawBytes.size / 2
                val shorts = ShortArray(shortCount)
                ByteBuffer.wrap(rawBytes).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().get(shorts)

                return if (channels == 1) {
                    val floats = FloatArray(shortCount) { shorts[it] / 32768.0f }
                    floats to sampleRate
                } else {
                    // Mix stereo to mono
                    val monoCount = shortCount / channels
                    val floats = FloatArray(monoCount) { i ->
                        var sum = 0f
                        for (c in 0 until channels) {
                            sum += shorts[i * channels + c] / 32768.0f
                        }
                        sum / channels
                    }
                    floats to sampleRate
                }
            } else {
                return decodeMediaCodec(file)
            }
        }
    }

    private fun decodeMediaCodec(file: File): Pair<FloatArray, Int> {
        val extractor = MediaExtractor()
        try {
            extractor.setDataSource(file.absolutePath)
            var audioTrackIndex = -1
            var format: MediaFormat? = null

            for (i in 0 until extractor.trackCount) {
                val trackFormat = extractor.getTrackFormat(i)
                val mime = trackFormat.getString(MediaFormat.KEY_MIME) ?: ""
                if (mime.startsWith("audio/")) {
                    audioTrackIndex = i
                    format = trackFormat
                    break
                }
            }

            if (audioTrackIndex < 0 || format == null) {
                return FloatArray(0) to 44100
            }

            extractor.selectTrack(audioTrackIndex)
            val mime = format.getString(MediaFormat.KEY_MIME) ?: "audio/mpeg"
            val sampleRate = if (format.containsKey(MediaFormat.KEY_SAMPLE_RATE)) format.getInteger(MediaFormat.KEY_SAMPLE_RATE) else 44100
            val channelCount = if (format.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) format.getInteger(MediaFormat.KEY_CHANNEL_COUNT) else 1

            val codec = MediaCodec.createDecoderByType(mime)
            codec.configure(format, null, null, 0)
            codec.start()

            val info = MediaCodec.BufferInfo()
            val pcmBytes = ArrayList<Byte>()
            var isEos = false

            val timeoutUs = 5000L
            while (!isEos) {
                val inIndex = codec.dequeueInputBuffer(timeoutUs)
                if (inIndex >= 0) {
                    val inBuffer = codec.getInputBuffer(inIndex)
                    inBuffer?.clear()
                    val sampleSize = inBuffer?.let { extractor.readSampleData(it, 0) } ?: -1
                    if (sampleSize < 0) {
                        codec.queueInputBuffer(inIndex, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                    } else {
                        codec.queueInputBuffer(inIndex, 0, sampleSize, extractor.sampleTime, 0)
                        extractor.advance()
                    }
                }

                val outIndex = codec.dequeueOutputBuffer(info, timeoutUs)
                if (outIndex >= 0) {
                    val outBuffer = codec.getOutputBuffer(outIndex)
                    if (outBuffer != null && info.size > 0) {
                        val chunk = ByteArray(info.size)
                        outBuffer.position(info.offset)
                        outBuffer.get(chunk)
                        for (b in chunk) pcmBytes.add(b)
                    }
                    codec.releaseOutputBuffer(outIndex, false)
                    if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                        isEos = true
                    }
                }
            }

            codec.stop()
            codec.release()

            val byteArr = ByteArray(pcmBytes.size) { pcmBytes[it] }
            val shortCount = byteArr.size / 2
            val shorts = ShortArray(shortCount)
            ByteBuffer.wrap(byteArr).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().get(shorts)

            val monoCount = shortCount / channelCount.coerceAtLeast(1)
            val floats = FloatArray(monoCount) { i ->
                var sum = 0f
                for (c in 0 until channelCount) {
                    val idx = i * channelCount + c
                    if (idx < shorts.size) {
                        sum += shorts[idx] / 32768.0f
                    }
                }
                sum / channelCount.coerceAtLeast(1)
            }

            return floats to sampleRate
        } catch (e: Exception) {
            e.printStackTrace()
            return FloatArray(0) to 44100
        } finally {
            try {
                extractor.release()
            } catch (_: Exception) {}
        }
    }
}
