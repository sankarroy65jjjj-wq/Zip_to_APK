package com.example.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File
import java.util.concurrent.ConcurrentHashMap

/**
 * Low-latency AudioPlayer wrapper around Android's SoundPool.
 * Handles:
 * - Ultra-low-latency touch-to-sound triggering
 * - Asynchronous load completion queueing (zero missed hits)
 * - Dynamic on-the-fly pitch (playback rate) adjustments on active streams
 * - Dynamic on-the-fly volume adjustments on active streams
 * - Multi-voice polyphony management (up to 32 simultaneous streams)
 * - Pad-level stream tracking (choke, pitch bend, volume ducking)
 */
class AudioPlayer(
    private val context: Context,
    private val scope: CoroutineScope
) {
    companion object {
        private const val TAG = "AudioPlayer"
        private const val MAX_STREAMS = 32
    }

    private val soundPool: SoundPool
    // Map of CacheKey -> SoundPool soundId
    private val soundIdCache = ConcurrentHashMap<String, Int>()
    // Set of soundIds that are confirmed loaded and ready to play
    private val readySoundIds = ConcurrentHashMap.newKeySet<Int>()
    // Pending play actions queued while sound was loading: soundId -> List of pending play invocations
    private val pendingPlayQueue = ConcurrentHashMap<Int, MutableList<QueuedPlayRequest>>()

    // Map of padNumber -> List of currently active streamIds
    private val padActiveStreams = ConcurrentHashMap<Int, MutableList<Int>>()
    // Map of streamId -> padNumber
    private val streamToPadMap = ConcurrentHashMap<Int, Int>()

    data class QueuedPlayRequest(
        val padNumber: Int,
        val volume: Float,
        val pitch: Float,
        val onStreamStarted: ((Int) -> Unit)? = null
    )

    init {
        val attributes = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_GAME)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .setFlags(AudioAttributes.FLAG_AUDIBILITY_ENFORCED)
            .build()

        soundPool = SoundPool.Builder()
            .setMaxStreams(MAX_STREAMS)
            .setAudioAttributes(attributes)
            .build()

        soundPool.setOnLoadCompleteListener { _, sampleId, status ->
            if (status == 0) {
                readySoundIds.add(sampleId)
                // Drain any pending play requests immediately
                val queuedList = pendingPlayQueue.remove(sampleId)
                queuedList?.forEach { request ->
                    val streamId = soundPool.play(
                        sampleId,
                        request.volume,
                        request.volume,
                        1,
                        0,
                        request.pitch.coerceIn(0.5f, 2.0f)
                    )
                    if (streamId > 0) {
                        trackStream(request.padNumber, streamId)
                        request.onStreamStarted?.invoke(streamId)
                    }
                }
            } else {
                Log.e(TAG, "Failed to load sampleId: $sampleId with status: $status")
                pendingPlayQueue.remove(sampleId)
            }
        }
    }

    /**
     * Preloads an audio file into SoundPool memory.
     * Returns true if already ready, false if loading asynchronously.
     */
    fun preload(key: String, file: File, onLoaded: (() -> Unit)? = null): Boolean {
        if (!file.exists()) return false

        val existingId = soundIdCache[key]
        if (existingId != null && readySoundIds.contains(existingId)) {
            onLoaded?.invoke()
            return true
        }

        if (existingId != null) {
            // Already loading
            if (onLoaded != null) {
                val list = pendingPlayQueue.getOrPut(existingId) { mutableListOf() }
                list.add(QueuedPlayRequest(-1, 0f, 1f) { onLoaded.invoke() })
            }
            return false
        }

        try {
            val soundId = soundPool.load(file.absolutePath, 1)
            if (soundId > 0) {
                soundIdCache[key] = soundId
                if (onLoaded != null) {
                    val list = pendingPlayQueue.getOrPut(soundId) { mutableListOf() }
                    list.add(QueuedPlayRequest(-1, 0f, 1f) { onLoaded.invoke() })
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Exception loading file: ${file.absolutePath}", e)
        }
        return false
    }

    /**
     * Plays a sound with zero latency.
     * If the sound is still loading, it is queued and played the exact millisecond it finishes decoding.
     */
    fun play(
        key: String,
        file: File,
        padNumber: Int,
        volume: Float,
        pitch: Float,
        onStreamStarted: ((Int) -> Unit)? = null
    ): Int {
        val safeVol = volume.coerceIn(0.01f, 1.0f)
        val safePitch = pitch.coerceIn(0.5f, 2.0f)

        val soundId = soundIdCache[key]
        if (soundId != null && readySoundIds.contains(soundId)) {
            val streamId = soundPool.play(soundId, safeVol, safeVol, 1, 0, safePitch)
            if (streamId > 0) {
                trackStream(padNumber, streamId)
                onStreamStarted?.invoke(streamId)
            }
            return streamId
        }

        // Not yet loaded: load and queue
        val targetId = soundId ?: run {
            if (!file.exists()) return 0
            val newId = soundPool.load(file.absolutePath, 1)
            if (newId > 0) soundIdCache[key] = newId
            newId
        }

        if (targetId > 0) {
            val list = pendingPlayQueue.getOrPut(targetId) { mutableListOf() }
            list.add(QueuedPlayRequest(padNumber, safeVol, safePitch, onStreamStarted))
        }
        return 0
    }

    /**
     * Dynamically adjusts pitch (playback rate) on the fly for currently playing streams of a pad.
     */
    fun setPitchOnTheFly(padNumber: Int, pitch: Float) {
        val safePitch = pitch.coerceIn(0.5f, 2.0f)
        val activeList = padActiveStreams[padNumber] ?: return
        activeList.toList().forEach { streamId ->
            try {
                soundPool.setRate(streamId, safePitch)
            } catch (_: Exception) {}
        }
    }

    /**
     * Dynamically adjusts volume on the fly for currently playing streams of a pad.
     */
    fun setVolumeOnTheFly(padNumber: Int, volume: Float) {
        val safeVol = volume.coerceIn(0.0f, 1.0f)
        val activeList = padActiveStreams[padNumber] ?: return
        activeList.toList().forEach { streamId ->
            try {
                soundPool.setVolume(streamId, safeVol, safeVol)
            } catch (_: Exception) {}
        }
    }

    /**
     * Dynamically adjusts pitch for a specific streamId.
     */
    fun setStreamPitch(streamId: Int, pitch: Float) {
        if (streamId > 0) {
            try {
                soundPool.setRate(streamId, pitch.coerceIn(0.5f, 2.0f))
            } catch (_: Exception) {}
        }
    }

    /**
     * Dynamically adjusts volume for a specific streamId.
     */
    fun setStreamVolume(streamId: Int, volume: Float) {
        if (streamId > 0) {
            try {
                val safeVol = volume.coerceIn(0.0f, 1.0f)
                soundPool.setVolume(streamId, safeVol, safeVol)
            } catch (_: Exception) {}
        }
    }

    /**
     * Choke/Stop all active streams of a given pad.
     */
    fun stopPad(padNumber: Int) {
        val activeList = padActiveStreams.remove(padNumber) ?: return
        activeList.forEach { streamId ->
            try {
                soundPool.stop(streamId)
                streamToPadMap.remove(streamId)
            } catch (_: Exception) {}
        }
    }

    /**
     * Stop all active playback voices immediately.
     */
    fun stopAll() {
        padActiveStreams.values.forEach { list ->
            list.forEach { streamId ->
                try { soundPool.stop(streamId) } catch (_: Exception) {}
            }
        }
        padActiveStreams.clear()
        streamToPadMap.clear()
    }

    private fun trackStream(padNumber: Int, streamId: Int) {
        if (streamId <= 0 || padNumber <= 0) return
        val list = padActiveStreams.getOrPut(padNumber) { mutableListOf() }
        list.add(streamId)
        if (list.size > 8) {
            // Keep at most 8 overlapping streams per pad
            list.removeAt(0)
        }
        streamToPadMap[streamId] = padNumber
    }

    fun release() {
        try {
            stopAll()
            soundPool.release()
            soundIdCache.clear()
            readySoundIds.clear()
            pendingPlayQueue.clear()
        } catch (e: Exception) {
            Log.e(TAG, "Error releasing sound pool", e)
        }
    }
}
