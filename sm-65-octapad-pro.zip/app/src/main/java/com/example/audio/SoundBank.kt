package com.example.audio

import android.content.Context
import com.example.data.local.DefaultPatches
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

class SoundBank(private val context: Context) {

    private val factoryDir: File = File(context.filesDir, "factory_sounds").apply { mkdirs() }
    val customDir: File = File(context.filesDir, "custom_sounds").apply { mkdirs() }

    suspend fun initializeFactorySounds() = withContext(Dispatchers.IO) {
        for ((soundId, _) in DefaultPatches.FACTORY_SOUNDS) {
            val file = File(factoryDir, "$soundId.wav")
            if (!file.exists() || file.length() < 100) {
                val samples = WavGenerator.generatePercussionSample(soundId)
                WavGenerator.writeWavFile(file, samples)
            }
        }
    }

    fun getSoundFile(soundId: String, isCustom: Boolean): File {
        return if (isCustom) {
            File(soundId) // For custom sounds, soundId is the file path
        } else {
            File(factoryDir, "$soundId.wav")
        }
    }

    fun getFactorySounds(): List<Pair<String, String>> = DefaultPatches.FACTORY_SOUNDS

    fun getCustomSounds(): List<File> {
        return customDir.listFiles { file ->
            file.isFile && (file.name.endsWith(".wav", ignoreCase = true) || file.name.endsWith(".mp3", ignoreCase = true))
        }?.toList() ?: emptyList()
    }
}
