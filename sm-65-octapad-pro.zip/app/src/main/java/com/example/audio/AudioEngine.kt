package com.example.audio

import android.content.Context
import com.example.data.model.PadConfig
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File
import java.util.concurrent.ConcurrentHashMap

class AudioEngine(
    private val context: Context,
    private val soundBank: SoundBank,
    private val scope: CoroutineScope
) {

    val audioPlayer = AudioPlayer(context, scope)
    // Key -> Resolved File
    private val resolvedFiles = ConcurrentHashMap<String, File>()

    /**
     * Preloads all sounds for the given pads so hitting them has zero latency.
     */
    fun preloadPadSounds(pads: List<PadConfig>, patchNumber: Int) {
        scope.launch(Dispatchers.IO) {
            for (pad in pads) {
                val key = getCacheKey(pad, patchNumber)
                val file = getOrResolveFile(pad, patchNumber)
                if (file.exists()) {
                    audioPlayer.preload(key, file)
                }
            }
        }
    }

    private suspend fun getOrResolveFile(pad: PadConfig, patchNumber: Int): File {
        val key = getCacheKey(pad, patchNumber)
        resolvedFiles[key]?.let { return it }

        val file = if (pad.autoTrimEnabled && pad.trimStartMs > 0) {
            val original = soundBank.getSoundFile(pad.soundId, pad.isCustom)
            if (original.exists()) {
                AudioTrimAnalyzer.createTrimmedWav(
                    context = context,
                    originalFile = original,
                    trimStartMs = pad.trimStartMs,
                    padNumber = pad.padNumber,
                    patchNumber = patchNumber
                )
            } else {
                original
            }
        } else {
            soundBank.getSoundFile(pad.soundId, pad.isCustom)
        }

        resolvedFiles[key] = file
        return file
    }

    private fun getCacheKey(pad: PadConfig, patchNumber: Int): String {
        return if (pad.autoTrimEnabled && pad.trimStartMs > 0) {
            "p${patchNumber}_pad${pad.padNumber}_${pad.soundId}_trim_${pad.trimStartMs}"
        } else {
            "pad_${pad.soundId}_${pad.isCustom}"
        }
    }

    /**
     * Play pad sound with responsive volume, pitch, reverb, and echo delay taps.
     */
    fun playPad(pad: PadConfig, patchNumber: Int, velocity: Float = 1.0f) {
        scope.launch(Dispatchers.Default) {
            val file = getOrResolveFile(pad, patchNumber)
            val key = getCacheKey(pad, patchNumber)
            if (!file.exists()) return@launch

            val effectiveVol = (pad.volume * velocity).coerceIn(0.01f, 1.0f)
            val effectivePitch = pad.pitch.coerceIn(0.5f, 2.0f)

            // Primary Hit
            audioPlayer.play(
                key = key,
                file = file,
                padNumber = pad.padNumber,
                volume = effectiveVol,
                pitch = effectivePitch
            )

            // Echo Effect (Polyphonic decaying delay taps)
            if (pad.echo > 0.05f) {
                val echoLevel = pad.echo.coerceIn(0.0f, 1.0f)
                val delayIntervalMs = 175L // 1/8th note delay
                val tapCount = if (echoLevel > 0.6f) 3 else 2

                var currentEchoVol = effectiveVol * echoLevel * 0.6f
                for (tap in 1..tapCount) {
                    delay(delayIntervalMs)
                    if (currentEchoVol > 0.02f) {
                        audioPlayer.play(
                            key = key,
                            file = file,
                            padNumber = pad.padNumber,
                            volume = currentEchoVol,
                            pitch = effectivePitch
                        )
                        currentEchoVol *= 0.55f // Decay multiplier
                    }
                }
            }

            // Reverb Simulation (Ambient room tail)
            if (pad.reverb > 0.15f) {
                val reverbVol = effectiveVol * pad.reverb * 0.22f
                delay(30)
                audioPlayer.play(
                    key = key,
                    file = file,
                    padNumber = pad.padNumber,
                    volume = reverbVol,
                    pitch = effectivePitch * 0.98f
                )
            }
        }
    }

    /**
     * On-the-fly dynamic pitch adjustment for all active voices of a pad.
     */
    fun setPitchOnTheFly(padNumber: Int, pitch: Float) {
        audioPlayer.setPitchOnTheFly(padNumber, pitch)
    }

    /**
     * On-the-fly dynamic volume adjustment for all active voices of a pad.
     */
    fun setVolumeOnTheFly(padNumber: Int, volume: Float) {
        audioPlayer.setVolumeOnTheFly(padNumber, volume)
    }

    /**
     * Choke/mute playback on a specific pad.
     */
    fun stopPad(padNumber: Int) {
        audioPlayer.stopPad(padNumber)
    }

    /**
     * Preview sound (from Pad Editor).
     */
    fun previewSound(file: File, trimStartMs: Int = 0, volume: Float = 0.9f, pitch: Float = 1.0f) {
        scope.launch(Dispatchers.IO) {
            if (!file.exists()) return@launch

            val (targetFile, key) = if (trimStartMs > 0) {
                val trimmed = AudioTrimAnalyzer.createTrimmedWav(
                    context = context,
                    originalFile = file,
                    trimStartMs = trimStartMs,
                    padNumber = 999,
                    patchNumber = 999
                )
                trimmed to "preview_${trimmed.name}"
            } else {
                file to "preview_${file.name}"
            }

            audioPlayer.play(
                key = key,
                file = targetFile,
                padNumber = -1,
                volume = volume,
                pitch = pitch
            )
        }
    }

    fun release() {
        audioPlayer.release()
        resolvedFiles.clear()
    }
}
