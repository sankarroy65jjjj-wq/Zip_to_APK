package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val OctapadCharcoalDark = Color(0xFF0C0E12)
val OctapadChassis = Color(0xFF14171E)
val OctapadPadSurface = Color(0xFF1E242E)
val OctapadPadBorder = Color(0xFF2C3545)

val AccentOrange = Color(0xFFFF9100)
val AccentElectricCyan = Color(0xFF00E5FF)
val AccentLedGreen = Color(0xFF00E676)
val AccentInstrumentRed = Color(0xFFFF3D00)

val TextPrimary = Color(0xFFECEFF1)
val TextSecondary = Color(0xFF90A4AE)
val TextMuted = Color(0xFF607D8B)
