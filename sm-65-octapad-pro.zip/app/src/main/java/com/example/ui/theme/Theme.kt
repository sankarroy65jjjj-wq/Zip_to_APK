package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val OctapadColorScheme = darkColorScheme(
    primary = AccentOrange,
    onPrimary = Color.Black,
    secondary = AccentElectricCyan,
    onSecondary = Color.Black,
    tertiary = AccentLedGreen,
    onTertiary = Color.Black,
    background = OctapadCharcoalDark,
    onBackground = TextPrimary,
    surface = OctapadChassis,
    onSurface = TextPrimary,
    surfaceVariant = OctapadPadSurface,
    onSurfaceVariant = TextSecondary,
    outline = OctapadPadBorder
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = OctapadColorScheme,
        typography = Typography,
        content = content
    )
}
