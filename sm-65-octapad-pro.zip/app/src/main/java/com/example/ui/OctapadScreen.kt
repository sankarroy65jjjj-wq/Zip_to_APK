package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Usb
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.MidiSettingsDialog
import com.example.ui.components.PadEditorDialog
import com.example.ui.components.PadView
import com.example.ui.components.PatchListDialog
import com.example.ui.components.RenamePatchDialog

@Composable
fun OctapadScreen(viewModel: OctapadViewModel) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val allPatches by viewModel.allPatches.collectAsStateWithLifecycle()
    val midiStatus by viewModel.midiStatus.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(uiState.statusToast) {
        uiState.statusToast?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearStatusToast()
        }
    }

    val currentPatch = uiState.currentPatch

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = Color(0xFF0D0F12),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        contentWindowInsets = WindowInsets(0, 0, 0, 0)
    ) { _ ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.statusBars)
                .windowInsetsPadding(WindowInsets.navigationBars)
                .background(
                    Brush.verticalGradient(
                        colors = listOf(Color(0xFF14171E), Color(0xFF0C0E12), Color(0xFF090A0E))
                    )
                )
                .padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            // 1. TOP HEADER: BRANDING & MASTER CONTROLS
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Instrument Branding
                Column {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = "SM 65",
                            color = Color(0xFFFF9100),
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.Monospace,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "OCTAPAD PRO",
                            color = Color.White,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.5.sp
                        )
                    }
                    Text(
                        text = "PROFESSIONAL ELECTRONIC PERCUSSION SYSTEM",
                        color = Color(0xFF607D8B),
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }

                // Header Controls: MIDI Status & Master Volume
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // MIDI Status Pill
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(Color(0xFF1E242E))
                            .border(1.dp, if (midiStatus.connectedDeviceCount > 0) Color(0xFF00E676) else Color(0xFF37474F), RoundedCornerShape(6.dp))
                            .clickable { viewModel.openMidiDialog() }
                            .padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(7.dp)
                                .clip(CircleShape)
                                .background(if (midiStatus.connectedDeviceCount > 0) Color(0xFF00E676) else Color(0xFFFF9100))
                        )
                        Icon(
                            imageVector = Icons.Default.Usb,
                            contentDescription = "MIDI",
                            tint = Color(0xFF00E5FF),
                            modifier = Modifier.size(13.dp)
                        )
                        Text(
                            text = if (midiStatus.connectedDeviceCount > 0) "${midiStatus.connectedDeviceCount} MIDI" else "MIDI",
                            color = Color(0xFFCFD8DC),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    // Master Volume
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.width(110.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.VolumeUp,
                            contentDescription = "Master Volume",
                            tint = Color(0xFFFF9100),
                            modifier = Modifier.size(16.dp)
                        )
                        Slider(
                            value = uiState.masterVolume,
                            onValueChange = { viewModel.setMasterVolume(it) },
                            colors = SliderDefaults.colors(
                                thumbColor = Color(0xFFFF9100),
                                activeTrackColor = Color(0xFFFF9100),
                                inactiveTrackColor = Color(0xFF2E3846)
                            ),
                            modifier = Modifier.height(24.dp).testTag("master_volume_slider")
                        )
                    }
                }
            }

            // 2. PATCH DISPLAY & NAVIGATION BAR (SPD-20 VINTAGE LCD DISPLAY)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // PREV PATCH BUTTON
                Button(
                    onClick = { viewModel.prevPatch() },
                    modifier = Modifier
                        .height(52.dp)
                        .width(62.dp)
                        .testTag("prev_patch_button"),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E242E), contentColor = Color(0xFFFF9100))
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Previous Patch",
                        modifier = Modifier.size(20.dp)
                    )
                }

                // BACKLIT LCD PATCH DISPLAY
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(52.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .border(1.5.dp, Color(0xFF2B3A36), RoundedCornerShape(8.dp))
                        .background(Color(0xFF0B1411)) // Classic dark emerald/cyan LCD background
                        .clickable { viewModel.openPatchList() }
                        .padding(horizontal = 12.dp, vertical = 4.dp)
                        .testTag("patch_display_card")
                ) {
                    Row(
                        modifier = Modifier.fillMaxSize(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text(
                                    text = "PATCH #${"%03d".format(uiState.currentPatchNumber)}",
                                    color = Color(0xFF00E676),
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontFamily = FontFamily.Monospace,
                                    letterSpacing = 1.sp
                                )
                                Text(
                                    text = "/ 200",
                                    color = Color(0xFF00897B),
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                            Text(
                                text = (currentPatch?.name ?: "INITIALIZING...").uppercase(),
                                color = Color(0xFFE0F2F1),
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Black,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }

                        // Rename Action
                        IconButton(
                            onClick = { viewModel.openRenameDialog() },
                            modifier = Modifier.size(32.dp).testTag("rename_patch_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Edit,
                                contentDescription = "Rename Patch",
                                tint = Color(0xFF4DB6AC),
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }

                // NEXT PATCH BUTTON
                Button(
                    onClick = { viewModel.nextPatch() },
                    modifier = Modifier
                        .height(52.dp)
                        .width(62.dp)
                        .testTag("next_patch_button"),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E242E), contentColor = Color(0xFFFF9100))
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = "Next Patch",
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // 3. EIGHT ELECTRONIC TOUCH PADS (PROFESSIONAL 4x2 MATRIX)
            BoxWithConstraints(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF101217))
                    .border(1.dp, Color(0xFF202530), RoundedCornerShape(12.dp))
                    .padding(6.dp)
            ) {
                val availableWidth = maxWidth
                val availableHeight = maxHeight

                val pads = currentPatch?.pads ?: emptyList()

                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    // Top Row: Pads 1, 2, 3, 4
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        for (padIndex in 1..4) {
                            val pad = pads.find { it.padNumber == padIndex }
                            if (pad != null) {
                                val isTriggered = uiState.activeTriggers.containsKey(padIndex)
                                PadView(
                                    pad = pad,
                                    isTriggered = isTriggered,
                                    onHit = { velocity -> viewModel.hitPad(padIndex, velocity) },
                                    onEdit = { viewModel.openPadEditor(padIndex) },
                                    modifier = Modifier.weight(1f)
                                )
                            } else {
                                Spacer(modifier = Modifier.weight(1f))
                            }
                        }
                    }

                    // Bottom Row: Pads 5, 6, 7, 8
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        for (padIndex in 5..8) {
                            val pad = pads.find { it.padNumber == padIndex }
                            if (pad != null) {
                                val isTriggered = uiState.activeTriggers.containsKey(padIndex)
                                PadView(
                                    pad = pad,
                                    isTriggered = isTriggered,
                                    onHit = { velocity -> viewModel.hitPad(padIndex, velocity) },
                                    onEdit = { viewModel.openPadEditor(padIndex) },
                                    modifier = Modifier.weight(1f)
                                )
                            } else {
                                Spacer(modifier = Modifier.weight(1f))
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // 4. BOTTOM ACTION TOOLBAR
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(46.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Pad Edit Button
                Button(
                    onClick = { viewModel.openPadEditor(uiState.editingPadNumber) },
                    modifier = Modifier.weight(1f).height(46.dp).testTag("bottom_pad_edit_button"),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF263238), contentColor = Color(0xFFFF9100))
                ) {
                    Icon(Icons.Default.Tune, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("PAD EDIT", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                // Patch List (200) Button
                Button(
                    onClick = { viewModel.openPatchList() },
                    modifier = Modifier.weight(1f).height(46.dp).testTag("bottom_patch_list_button"),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF263238), contentColor = Color(0xFF00E5FF))
                ) {
                    Icon(Icons.Default.List, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("200 PATCHES", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                // MIDI Setup Button
                Button(
                    onClick = { viewModel.openMidiDialog() },
                    modifier = Modifier.weight(1f).height(46.dp).testTag("bottom_midi_setup_button"),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF263238), contentColor = Color(0xFF00E676))
                ) {
                    Icon(Icons.Default.Usb, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("MIDI SETUP", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // --- MODALS & DIALOGS ---

        // 1. Pad Editor Dialog
        if (uiState.isPadEditorOpen && currentPatch != null) {
            val padToEdit = currentPatch.pads.find { it.padNumber == uiState.editingPadNumber }
                ?: currentPatch.pads.firstOrNull()

            if (padToEdit != null) {
                PadEditorDialog(
                    pad = padToEdit,
                    soundBank = viewModel.soundBank,
                    onSave = { updatedPad -> viewModel.savePadConfig(updatedPad) },
                    onDismiss = { viewModel.closePadEditor() },
                    onPreviewSound = { file, trimStartMs, vol, pitch ->
                        viewModel.previewSound(file, trimStartMs, vol, pitch)
                    },
                    onImportAudio = { uri, name, callback ->
                        viewModel.importAudioFile(uri, name, callback)
                    },
                    onAnalyzeAudio = { file, threshold ->
                        viewModel.analyzeAudio(file, threshold)
                    },
                    onPitchChangeOnTheFly = { pitch ->
                        viewModel.setPadPitchOnTheFly(padToEdit.padNumber, pitch)
                    },
                    onVolumeChangeOnTheFly = { vol ->
                        viewModel.setPadVolumeOnTheFly(padToEdit.padNumber, vol)
                    }
                )
            }
        }

        // 2. 200 Patch List Dialog
        if (uiState.isPatchListOpen) {
            PatchListDialog(
                allPatches = allPatches,
                currentPatchNumber = uiState.currentPatchNumber,
                onSelectPatch = { number -> viewModel.selectPatch(number) },
                onDismiss = { viewModel.closePatchList() }
            )
        }

        // 3. MIDI & Trigger Settings Dialog
        if (uiState.isMidiDialogOpen) {
            MidiSettingsDialog(
                midiStatus = midiStatus,
                pads = currentPatch?.pads ?: emptyList(),
                onRefreshDevices = { viewModel.midiController.refreshDevices() },
                onDismiss = { viewModel.closeMidiDialog() }
            )
        }

        // 4. Rename Patch Dialog
        if (uiState.isRenameDialogOpen && currentPatch != null) {
            RenamePatchDialog(
                currentNumber = currentPatch.patchNumber,
                currentName = currentPatch.name,
                onSave = { newName -> viewModel.renamePatch(newName) },
                onDismiss = { viewModel.closeRenameDialog() }
            )
        }
    }
}
