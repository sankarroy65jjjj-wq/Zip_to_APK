package com.example.ui

import android.app.Application
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.AudioAnalysisResult
import com.example.audio.AudioEngine
import com.example.audio.AudioTrimAnalyzer
import com.example.audio.SoundBank
import com.example.data.local.OctapadDatabase
import com.example.data.local.PatchRepository
import com.example.data.model.PadConfig
import com.example.data.model.Patch
import com.example.midi.MidiController
import com.example.midi.MidiStatus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

data class OctapadUiState(
    val currentPatchNumber: Int = 1,
    val currentPatch: Patch? = null,
    val masterVolume: Float = 1.0f,
    val activeTriggers: Map<Int, Long> = emptyMap(), // padNumber -> trigger timestamp
    val isPadEditorOpen: Boolean = false,
    val editingPadNumber: Int = 1,
    val isPatchListOpen: Boolean = false,
    val isMidiDialogOpen: Boolean = false,
    val isRenameDialogOpen: Boolean = false,
    val statusToast: String? = null
)

class OctapadViewModel(application: Application) : AndroidViewModel(application) {

    private val db = OctapadDatabase.getDatabase(application)
    private val repository = PatchRepository(db.patchDao())
    val soundBank = SoundBank(application)
    val audioEngine = AudioEngine(application, soundBank, viewModelScope)

    private val vibrator: Vibrator? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        val manager = application.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
        manager?.defaultVibrator
    } else {
        @Suppress("DEPRECATION")
        application.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
    }

    private val _uiState = MutableStateFlow(OctapadUiState())
    val uiState: StateFlow<OctapadUiState> = _uiState.asStateFlow()

    val allPatches: StateFlow<List<Patch>> = repository.allPatches
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val midiController = MidiController(application) { noteNumber, velocity ->
        onExternalMidiTrigger(noteNumber, velocity)
    }

    val midiStatus: StateFlow<MidiStatus> = midiController.status

    init {
        viewModelScope.launch {
            // Initialize sounds and defaults
            soundBank.initializeFactorySounds()
            repository.initializeDefaultPatchesIfNeeded()

            // Observe current patch
            repository.getPatch(1).collect { patch ->
                if (patch != null && _uiState.value.currentPatch == null) {
                    _uiState.value = _uiState.value.copy(currentPatch = patch)
                    audioEngine.preloadPadSounds(patch.pads, patch.patchNumber)
                }
            }
        }
    }

    fun hitPad(padNumber: Int, velocity: Float = 1.0f) {
        val patch = _uiState.value.currentPatch ?: return
        val pad = patch.pads.find { it.padNumber == padNumber } ?: return

        // Play audio
        audioEngine.playPad(pad, patch.patchNumber, velocity * _uiState.value.masterVolume)

        // Haptic feedback
        triggerHaptic()

        // Flash visual trigger
        val updatedMap = _uiState.value.activeTriggers.toMutableMap()
        val now = System.currentTimeMillis()
        updatedMap[padNumber] = now
        _uiState.value = _uiState.value.copy(activeTriggers = updatedMap)

        // Auto-clear trigger flash after 120ms
        viewModelScope.launch {
            delay(120)
            val currentMap = _uiState.value.activeTriggers.toMutableMap()
            if (currentMap[padNumber] == now) {
                currentMap.remove(padNumber)
                _uiState.value = _uiState.value.copy(activeTriggers = currentMap)
            }
        }
    }

    private fun triggerHaptic() {
        try {
            vibrator?.let { v ->
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    v.vibrate(VibrationEffect.createOneShot(18, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    v.vibrate(18)
                }
            }
        } catch (_: Exception) {}
    }

    private fun onExternalMidiTrigger(noteNumber: Int, velocity: Float) {
        val patch = _uiState.value.currentPatch ?: return
        val matchedPad = patch.pads.find { it.midiNote == noteNumber }
        if (matchedPad != null) {
            hitPad(matchedPad.padNumber, velocity)
        }
    }

    fun nextPatch() {
        val next = if (_uiState.value.currentPatchNumber >= 200) 1 else _uiState.value.currentPatchNumber + 1
        selectPatch(next)
    }

    fun prevPatch() {
        val prev = if (_uiState.value.currentPatchNumber <= 1) 200 else _uiState.value.currentPatchNumber - 1
        selectPatch(prev)
    }

    fun selectPatch(number: Int) {
        val validNumber = number.coerceIn(1, 200)
        viewModelScope.launch {
            val patch = repository.getPatchDirect(validNumber) ?: return@launch
            _uiState.value = _uiState.value.copy(
                currentPatchNumber = validNumber,
                currentPatch = patch
            )
            audioEngine.preloadPadSounds(patch.pads, validNumber)
        }
    }

    fun renamePatch(newName: String) {
        val current = _uiState.value.currentPatch ?: return
        val trimmed = newName.trim()
        if (trimmed.isEmpty()) return

        viewModelScope.launch {
            repository.renamePatch(current.patchNumber, trimmed)
            val updated = current.copy(name = trimmed)
            _uiState.value = _uiState.value.copy(
                currentPatch = updated,
                isRenameDialogOpen = false
            )
        }
    }

    fun setMasterVolume(vol: Float) {
        _uiState.value = _uiState.value.copy(masterVolume = vol.coerceIn(0f, 1f))
    }

    fun setPadPitchOnTheFly(padNumber: Int, pitch: Float) {
        audioEngine.setPitchOnTheFly(padNumber, pitch)
    }

    fun setPadVolumeOnTheFly(padNumber: Int, volume: Float) {
        audioEngine.setVolumeOnTheFly(padNumber, volume)
    }

    fun openPadEditor(padNumber: Int) {
        _uiState.value = _uiState.value.copy(
            isPadEditorOpen = true,
            editingPadNumber = padNumber
        )
    }

    fun closePadEditor() {
        _uiState.value = _uiState.value.copy(isPadEditorOpen = false)
    }

    fun openPatchList() {
        _uiState.value = _uiState.value.copy(isPatchListOpen = true)
    }

    fun closePatchList() {
        _uiState.value = _uiState.value.copy(isPatchListOpen = false)
    }

    fun openMidiDialog() {
        midiController.refreshDevices()
        _uiState.value = _uiState.value.copy(isMidiDialogOpen = true)
    }

    fun closeMidiDialog() {
        _uiState.value = _uiState.value.copy(isMidiDialogOpen = false)
    }

    fun openRenameDialog() {
        _uiState.value = _uiState.value.copy(isRenameDialogOpen = true)
    }

    fun closeRenameDialog() {
        _uiState.value = _uiState.value.copy(isRenameDialogOpen = false)
    }

    fun savePadConfig(updatedPad: PadConfig) {
        val patch = _uiState.value.currentPatch ?: return
        val newPads = patch.pads.map { if (it.padNumber == updatedPad.padNumber) updatedPad else it }
        val updatedPatch = patch.copy(pads = newPads)

        viewModelScope.launch {
            repository.savePatch(updatedPatch)
            _uiState.value = _uiState.value.copy(
                currentPatch = updatedPatch,
                isPadEditorOpen = false
            )
            audioEngine.preloadPadSounds(newPads, patch.patchNumber)
        }
    }

    fun importAudioFile(uri: Uri, displayName: String, onComplete: (File) -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val cleanName = displayName.replace("[^a-zA-Z0-9._-]".toRegex(), "_")
                val destFile = File(soundBank.customDir, "${System.currentTimeMillis()}_$cleanName")
                val context = getApplication<Application>()

                context.contentResolver.openInputStream(uri)?.use { input ->
                    FileOutputStream(destFile).use { output ->
                        input.copyTo(output)
                    }
                }

                withContext(Dispatchers.Main) {
                    onComplete(destFile)
                }
            } catch (e: Exception) {
                e.printStackTrace()
                withContext(Dispatchers.Main) {
                    _uiState.value = _uiState.value.copy(statusToast = "Failed to import audio: ${e.localizedMessage}")
                }
            }
        }
    }

    suspend fun analyzeAudio(file: File, threshold: Float): AudioAnalysisResult {
        return AudioTrimAnalyzer.analyzeFile(file, threshold)
    }

    fun previewSound(file: File, trimStartMs: Int = 0, volume: Float = 0.9f, pitch: Float = 1.0f) {
        audioEngine.previewSound(file, trimStartMs, volume, pitch)
    }

    fun clearStatusToast() {
        _uiState.value = _uiState.value.copy(statusToast = null)
    }

    override fun onCleared() {
        super.onCleared()
        audioEngine.release()
        midiController.release()
    }
}
