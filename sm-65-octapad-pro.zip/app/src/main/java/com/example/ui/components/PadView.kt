package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.PadConfig

@Composable
fun PadView(
    pad: PadConfig,
    isTriggered: Boolean,
    onHit: (velocity: Float) -> Unit,
    onEdit: () -> Unit,
    modifier: Modifier = Modifier
) {
    // Dynamic scale for trigger impact bounce
    val scale by animateFloatAsState(
        targetValue = if (isTriggered) 0.96f else 1.0f,
        animationSpec = tween(durationMillis = 80, easing = FastOutSlowInEasing),
        label = "padScale"
    )

    // Animated glow color: electric cyan/amber flash on strike
    val glowColor by animateColorAsState(
        targetValue = if (isTriggered) {
            if (pad.padNumber in 1..4) Color(0xFFFF9100) else Color(0xFF00E5FF)
        } else {
            Color(0xFF2C3240)
        },
        animationSpec = tween(durationMillis = 100),
        label = "padGlow"
    )

    val surfaceColor by animateColorAsState(
        targetValue = if (isTriggered) Color(0xFF323B4A) else Color(0xFF181C22),
        animationSpec = tween(durationMillis = 100),
        label = "padSurface"
    )

    val shape = RoundedCornerShape(14.dp)

    Box(
        modifier = modifier
            .testTag("pad_${pad.padNumber}")
            .scale(scale)
            .clip(shape)
            .border(
                width = if (isTriggered) 2.5.dp else 1.5.dp,
                color = glowColor,
                shape = shape
            )
            .background(surfaceColor)
            .drawBehind {
                // Subtle Roland-style rubber surface texture grid
                val step = 16.dp.toPx()
                var x = 0f
                while (x < size.width) {
                    drawLine(
                        color = Color(0x0CFFFFFF),
                        start = Offset(x, 0f),
                        end = Offset(x, size.height),
                        strokeWidth = 1f
                    )
                    x += step
                }
                // Ambient vignette shadow
                drawRect(
                    brush = Brush.radialGradient(
                        colors = listOf(Color.Transparent, Color(0x66000000)),
                        center = center,
                        radius = size.maxDimension / 1.5f
                    )
                )
            }
            .pointerInput(pad.padNumber) {
                detectTapGestures(
                    onPress = {
                        onHit(1.0f)
                    }
                )
            }
            .padding(8.dp)
    ) {
        // Pad Header: Pad Number & Edit Icon
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.TopStart),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Pad Number Badge
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(if (isTriggered) glowColor else Color(0xFF4A5568))
                )
                Text(
                    text = "PAD ${pad.padNumber}",
                    color = if (isTriggered) glowColor else Color(0xFF90A4AE),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }

            // Quick Edit Button
            IconButton(
                onClick = onEdit,
                modifier = Modifier
                    .size(32.dp)
                    .testTag("pad_edit_btn_${pad.padNumber}")
            ) {
                Icon(
                    imageVector = Icons.Default.Tune,
                    contentDescription = "Edit Pad ${pad.padNumber}",
                    tint = Color(0xFF78909C),
                    modifier = Modifier.size(16.dp)
                )
            }
        }

        // Center: Large, punchy Sound Name
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(vertical = 18.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = pad.soundName.uppercase(),
                color = if (isTriggered) Color.White else Color(0xFFECEFF1),
                fontSize = 15.sp,
                fontWeight = FontWeight.Black,
                textAlign = TextAlign.Center,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                lineHeight = 18.sp
            )

            if (pad.isCustom) {
                Text(
                    text = "CUSTOM",
                    color = Color(0xFF00E5FF),
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.padding(top = 2.dp)
                )
            }
        }

        // Bottom parameter indicators: Vol, Pitch, FX & Trim badges
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Volume & Pitch tag
            Text(
                text = "V:${(pad.volume * 100).toInt()}%  P:${"%.1f".format(pad.pitch)}x",
                color = Color(0xFF607D8B),
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Medium
            )

            // FX active indicators
            Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                if (pad.echo > 0.05f) {
                    ParamPill(label = "ECH", color = Color(0xFFFF9100))
                }
                if (pad.reverb > 0.15f) {
                    ParamPill(label = "REV", color = Color(0xFF00E5FF))
                }
                if (pad.autoTrimEnabled && pad.trimStartMs > 0) {
                    ParamPill(label = "TRM", color = Color(0xFF00E676))
                }
            }
        }
    }
}

@Composable
private fun ParamPill(label: String, color: Color) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(3.dp))
            .background(color.copy(alpha = 0.2f))
            .padding(horizontal = 3.dp, vertical = 1.dp)
    ) {
        Text(
            text = label,
            color = color,
            fontSize = 8.sp,
            fontWeight = FontWeight.ExtraBold,
            fontFamily = FontFamily.Monospace
        )
    }
}
