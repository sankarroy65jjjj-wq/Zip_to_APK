package com.example.ui.components

import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FileOpen
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.audio.AudioAnalysisResult
import com.example.audio.SoundBank
import com.example.data.model.PadConfig
import kotlinx.coroutines.launch
import java.io.File

@Composable
fun PadEditorDialog(
    pad: PadConfig,
    soundBank: SoundBank,
    onSave: (PadConfig) -> Unit,
    onDismiss: () -> Unit,
    onPreviewSound: (file: File, trimStartMs: Int, volume: Float, pitch: Float) -> Unit,
    onImportAudio: (Uri, String, (File) -> Unit) -> Unit,
    onAnalyzeAudio: suspend (File, Float) -> AudioAnalysisResult,
    onPitchChangeOnTheFly: ((Float) -> Unit)? = null,
    onVolumeChangeOnTheFly: ((Float) -> Unit)? = null
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    // Local mutable state for editing without mutating parent prematurely
    var soundId by remember { mutableStateOf(pad.soundId) }
    var soundName by remember { mutableStateOf(pad.soundName) }
    var isCustom by remember { mutableStateOf(pad.isCustom) }
    var volume by remember { mutableFloatStateOf(pad.volume) }
    var pitch by remember { mutableFloatStateOf(pad.pitch) }
    var reverb by remember { mutableFloatStateOf(pad.reverb) }
    var echo by remember { mutableFloatStateOf(pad.echo) }
    var autoTrimEnabled by remember { mutableStateOf(pad.autoTrimEnabled) }
    var trimStartMs by remember { mutableIntStateOf(pad.trimStartMs) }
    var trimThreshold by remember { mutableFloatStateOf(pad.trimThreshold) }
    var midiNote by remember { mutableIntStateOf(pad.midiNote) }

    // Waveform analysis state
    var analysisResult by remember { mutableStateOf<AudioAnalysisResult?>(null) }
    var showSoundDropdown by remember { mutableStateOf(false) }

    // Re-analyze audio when sound file or threshold changes
    fun runAnalysis(threshold: Float) {
        scope.launch {
            val file = soundBank.getSoundFile(soundId, isCustom)
            if (file.exists()) {
                val res = onAnalyzeAudio(file, threshold)
                analysisResult = res
                if (autoTrimEnabled && trimStartMs == 0) {
                    trimStartMs = res.detectedTrimStartMs
                }
            }
        }
    }

    LaunchedEffect(soundId, isCustom) {
        runAnalysis(trimThreshold)
    }

    // Audio file picker launcher
    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            var fileName = "imported_audio.wav"
            try {
                context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                    val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (cursor.moveToFirst() && nameIndex >= 0) {
                        fileName = cursor.getString(nameIndex)
                    }
                }
            } catch (_: Exception) {}

            onImportAudio(uri, fileName) { savedFile ->
                soundId = savedFile.absolutePath
                soundName = fileName.substringBeforeLast(".")
                isCustom = true
                autoTrimEnabled = true // Default auto trim on import
                trimStartMs = 0
                runAnalysis(trimThreshold)
            }
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.96f)
                .heightIn(max = 680.dp)
                .clip(RoundedCornerShape(16.dp))
                .border(1.5.dp, Color(0xFF37474F), RoundedCornerShape(16.dp))
                .background(Color(0xFF14171D)),
            color = Color(0xFF14171D)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // Dialog Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(12.dp)
                                .clip(RoundedCornerShape(3.dp))
                                .background(Color(0xFFFF9100))
                        )
                        Text(
                            text = "PAD ${pad.padNumber} CONFIGURATOR",
                            color = Color.White,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.LightGray)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Section 1: Sound Assignment & Load Sound
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E232B)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "SOUND ASSIGNMENT",
                            color = Color(0xFF90A4AE),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Spacer(modifier = Modifier.height(6.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = soundName.uppercase(),
                                    color = Color.White,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Black
                                )
                                Text(
                                    text = if (isCustom) "User Imported WAV/MP3" else "Factory Percussion Bank",
                                    color = if (isCustom) Color(0xFF00E5FF) else Color(0xFF78909C),
                                    fontSize = 11.sp
                                )
                            }

                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                // Load Sound Button
                                Box {
                                    Button(
                                        onClick = { showSoundDropdown = true },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E3846)),
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.testTag("load_sound_button")
                                    ) {
                                        Icon(Icons.Default.Tune, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Select", fontSize = 12.sp)
                                    }

                                    DropdownMenu(
                                        expanded = showSoundDropdown,
                                        onDismissRequest = { showSoundDropdown = false },
                                        modifier = Modifier.background(Color(0xFF222832))
                                    ) {
                                        Text(
                                            text = "— FACTORY PERCUSSION —",
                                            color = Color(0xFFFF9100),
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                                        )
                                        soundBank.getFactorySounds().forEach { (fId, fName) ->
                                            DropdownMenuItem(
                                                text = { Text(fName, color = Color.White, fontSize = 13.sp) },
                                                onClick = {
                                                    soundId = fId
                                                    soundName = fName
                                                    isCustom = false
                                                    showSoundDropdown = false
                                                }
                                            )
                                        }

                                        val customSounds = soundBank.getCustomSounds()
                                        if (customSounds.isNotEmpty()) {
                                            Text(
                                                text = "— CUSTOM IMPORTS —",
                                                color = Color(0xFF00E5FF),
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                                            )
                                            customSounds.forEach { file ->
                                                DropdownMenuItem(
                                                    text = { Text(file.nameWithoutExtension, color = Color.White, fontSize = 13.sp) },
                                                    onClick = {
                                                        soundId = file.absolutePath
                                                        soundName = file.nameWithoutExtension
                                                        isCustom = true
                                                        showSoundDropdown = false
                                                    }
                                                )
                                            }
                                        }
                                    }
                                }

                                // Import from Device
                                OutlinedButton(
                                    onClick = { filePickerLauncher.launch("audio/*") },
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF00E5FF)),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.testTag("import_audio_button")
                                ) {
                                    Icon(Icons.Default.FileOpen, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Import", fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Section 2: Pad Performance Parameters (Sliders)
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E232B)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "PERFORMANCE PARAMETERS",
                            color = Color(0xFF90A4AE),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        // Volume Slider
                        ParamSlider(
                            label = "Pad Volume",
                            value = volume,
                            valueDisplay = "${(volume * 100).toInt()}%",
                            onValueChange = {
                                volume = it
                                onVolumeChangeOnTheFly?.invoke(it)
                            },
                            accentColor = Color(0xFFFF9100)
                        )

                        // Pitch Slider
                        ParamSlider(
                            label = "Pitch / Playback Rate",
                            value = pitch,
                            range = 0.5f..2.0f,
                            valueDisplay = "${"%.2f".format(pitch)}x",
                            onValueChange = {
                                pitch = it
                                onPitchChangeOnTheFly?.invoke(it)
                            },
                            accentColor = Color(0xFF00E5FF)
                        )

                        // Reverb Slider
                        ParamSlider(
                            label = "Reverb Level",
                            value = reverb,
                            valueDisplay = "${(reverb * 100).toInt()}%",
                            onValueChange = { reverb = it },
                            accentColor = Color(0xFF29B6F6)
                        )

                        // Echo Slider
                        ParamSlider(
                            label = "Echo / Delay Level",
                            value = echo,
                            valueDisplay = "${(echo * 100).toInt()}%",
                            onValueChange = { echo = it },
                            accentColor = Color(0xFFFFB300)
                        )

                        // MIDI Trigger Note selector
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "External MIDI Note:",
                                color = Color(0xFFB0BEC5),
                                fontSize = 13.sp
                            )
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Button(
                                    onClick = { if (midiNote > 24) midiNote-- },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E3846)),
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Text("-", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                                }
                                Text(
                                    text = "$midiNote (${midiNoteToName(midiNote)})",
                                    color = Color(0xFF00E5FF),
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                                Button(
                                    onClick = { if (midiNote < 96) midiNote++ },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E3846)),
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Text("+", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Section 3: Auto Noise Trim & Waveform Analysis
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E232B)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "AUTO NOISE TRIM",
                                    color = Color(0xFF00E676),
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                                Text(
                                    text = "Detects leading silence & background noise",
                                    color = Color(0xFF78909C),
                                    fontSize = 10.sp
                                )
                            }
                            Switch(
                                checked = autoTrimEnabled,
                                onCheckedChange = { autoTrimEnabled = it },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = Color(0xFF00E676),
                                    checkedTrackColor = Color(0xFF1B5E20)
                                ),
                                modifier = Modifier.testTag("auto_trim_switch")
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Waveform visualization Canvas
                        val totalDurationMs = analysisResult?.durationMs?.coerceAtLeast(1) ?: 300
                        val waveform = analysisResult?.waveformPoints ?: FloatArray(100) { 0f }

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(64.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFF101318))
                                .border(1.dp, Color(0xFF263238), RoundedCornerShape(8.dp))
                        ) {
                            Canvas(modifier = Modifier.fillMaxSize().padding(horizontal = 6.dp, vertical = 4.dp)) {
                                val canvasWidth = size.width
                                val canvasHeight = size.height
                                val midY = canvasHeight / 2f
                                val barWidth = (canvasWidth / 100f).coerceAtLeast(1f)

                                val trimFraction = if (totalDurationMs > 0) {
                                    (trimStartMs.toFloat() / totalDurationMs).coerceIn(0f, 1f)
                                } else 0f
                                val trimX = trimFraction * canvasWidth

                                // Draw waveform bars
                                for (i in 0 until 100) {
                                    val x = i * barWidth
                                    val amp = (waveform[i] * (canvasHeight * 0.45f)).coerceAtLeast(1f)
                                    val isBeforeTrim = x < trimX && autoTrimEnabled

                                    val barColor = if (isBeforeTrim) {
                                        Color(0xFFE53935).copy(alpha = 0.5f) // Muted red for silence/noise
                                    } else {
                                        Color(0xFF00E676) // Bright green for sound attack
                                    }

                                    drawLine(
                                        color = barColor,
                                        start = Offset(x, midY - amp),
                                        end = Offset(x, midY + amp),
                                        strokeWidth = (barWidth * 0.8f).coerceAtLeast(1f)
                                    )
                                }

                                // Draw Trim Start marker line
                                if (autoTrimEnabled && trimStartMs > 0) {
                                    drawLine(
                                        color = Color(0xFFFF9100),
                                        start = Offset(trimX, 0f),
                                        end = Offset(trimX, canvasHeight),
                                        strokeWidth = 2.dp.toPx()
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Threshold slider & Manual Trim Start controls
                        if (autoTrimEnabled) {
                            ParamSlider(
                                label = "Noise Threshold Sensitivity",
                                value = trimThreshold,
                                range = 0.01f..0.25f,
                                valueDisplay = "${(trimThreshold * 100).toInt()}%",
                                onValueChange = {
                                    trimThreshold = it
                                    runAnalysis(it)
                                },
                                accentColor = Color(0xFF00E676)
                            )

                            ParamSlider(
                                label = "Manual Trim Start",
                                value = trimStartMs.toFloat(),
                                range = 0f..totalDurationMs.toFloat().coerceAtLeast(50f),
                                valueDisplay = "${trimStartMs}ms",
                                onValueChange = { trimStartMs = it.toInt() },
                                accentColor = Color(0xFFFF9100)
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Auto-detected: ${analysisResult?.detectedTrimStartMs ?: 0}ms",
                                    color = Color(0xFF90A4AE),
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                                OutlinedButton(
                                    onClick = { trimStartMs = 0 },
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFFF5252)),
                                    shape = RoundedCornerShape(6.dp),
                                    modifier = Modifier.testTag("reset_trim_button")
                                ) {
                                    Icon(Icons.Default.RestartAlt, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Reset Trim", fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Section 4: Preview Buttons
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E232B)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                val file = soundBank.getSoundFile(soundId, isCustom)
                                onPreviewSound(file, 0, volume, pitch)
                            },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("preview_original_button"),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFB0BEC5))
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Preview Orig", fontSize = 12.sp)
                        }

                        Button(
                            onClick = {
                                val file = soundBank.getSoundFile(soundId, isCustom)
                                val effectiveTrim = if (autoTrimEnabled) trimStartMs else 0
                                onPreviewSound(file, effectiveTrim, volume, pitch)
                            },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("preview_trimmed_button"),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00E676), contentColor = Color.Black)
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Preview Trimmed", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                // Section 5: Save & Cancel Action Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("cancel_pad_edit_button"),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFCFD8DC))
                    ) {
                        Text("CANCEL", fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = {
                            val updated = pad.copy(
                                soundId = soundId,
                                soundName = soundName,
                                isCustom = isCustom,
                                volume = volume,
                                pitch = pitch,
                                reverb = reverb,
                                echo = echo,
                                autoTrimEnabled = autoTrimEnabled,
                                trimStartMs = trimStartMs,
                                trimThreshold = trimThreshold,
                                midiNote = midiNote
                            )
                            onSave(updated)
                        },
                        modifier = Modifier
                            .weight(1.3f)
                            .height(48.dp)
                            .testTag("save_pad_edit_button"),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF9100), contentColor = Color.Black)
                    ) {
                        Text("SAVE PAD ${pad.padNumber}", fontWeight = FontWeight.Black)
                    }
                }
            }
        }
    }
}

@Composable
private fun ParamSlider(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float> = 0.0f..1.0f,
    valueDisplay: String,
    onValueChange: (Float) -> Unit,
    accentColor: Color
) {
    Column(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = label,
                color = Color(0xFFB0BEC5),
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium
            )
            Text(
                text = valueDisplay,
                color = accentColor,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
        }
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = range,
            colors = SliderDefaults.colors(
                thumbColor = accentColor,
                activeTrackColor = accentColor,
                inactiveTrackColor = Color(0xFF263238)
            ),
            modifier = Modifier.height(26.dp)
        )
    }
}

private fun midiNoteToName(note: Int): String {
    val noteNames = arrayOf("C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B")
    val octave = (note / 12) - 1
    val name = noteNames[note % 12]
    return "$name$octave"
}
