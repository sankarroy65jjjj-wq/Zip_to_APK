package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [PatchEntity::class], version = 1, exportSchema = false)
abstract class OctapadDatabase : RoomDatabase() {
    abstract fun patchDao(): PatchDao

    companion object {
        @Volatile
        private var INSTANCE: OctapadDatabase? = null

        fun getDatabase(context: Context): OctapadDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    OctapadDatabase::class.java,
                    "octapad_database.db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
