package com.example.data.model

data class PadConfig(
    val padNumber: Int, // 1..8
    val soundId: String,
    val soundName: String,
    val isCustom: Boolean = false,
    val volume: Float = 0.9f, // 0.0f .. 1.0f
    val pitch: Float = 1.0f,  // 0.5f .. 2.0f (1.0 = normal)
    val reverb: Float = 0.1f, // 0.0f .. 1.0f
    val echo: Float = 0.0f,   // 0.0f .. 1.0f
    val autoTrimEnabled: Boolean = false,
    val trimStartMs: Int = 0,
    val trimThreshold: Float = 0.05f,
    val midiNote: Int = 36 // GM drum note
)

data class Patch(
    val patchNumber: Int, // 1..200
    val name: String,
    val category: String, // "Acoustic", "Electronic", "World", "Special", "User"
    val pads: List<PadConfig>
)
