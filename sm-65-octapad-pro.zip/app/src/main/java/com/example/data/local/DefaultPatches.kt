package com.example.data.local

import com.example.data.model.PadConfig
import com.example.data.model.Patch

object DefaultPatches {

    val FACTORY_SOUNDS = listOf(
        "kick_acoustic" to "Acoustic Kick",
        "snare_crisp" to "Crisp Snare",
        "rim_shot" to "Rim Shot",
        "hihat_closed" to "Closed Hi-Hat",
        "hihat_open" to "Open Hi-Hat",
        "tom_high" to "High Tom",
        "tom_mid" to "Mid Tom",
        "tom_low" to "Low Floor Tom",
        "crash_cymbal" to "Crash Cymbal",
        "ride_bell" to "Ride Bell",
        "hand_clap" to "Hand Clap",
        "cowbell" to "Cowbell",
        "conga_high" to "High Conga",
        "conga_low" to "Low Conga",
        "bongo" to "Bongo Slap",
        "shaker" to "Shaker",
        "sub_808" to "808 Sub Boom",
        "tabla_dayan" to "Tabla Dayan",
        "tabla_bayan" to "Tabla Bayan",
        "dholak_bass" to "Dholak Bass",
        "dholak_treble" to "Dholak Treble",
        "tambourine" to "Tambourine"
    )

    fun createAll200Patches(): List<Patch> {
        val list = mutableListOf<Patch>()
        for (i in 1..200) {
            val (name, category, kitSounds) = getPatchMetadata(i)
            val pads = (1..8).map { padNum ->
                val sound = kitSounds.getOrElse(padNum - 1) { FACTORY_SOUNDS[0] }
                PadConfig(
                    padNumber = padNum,
                    soundId = sound.first,
                    soundName = sound.second,
                    isCustom = false,
                    volume = when (padNum) {
                        1 -> 0.95f // Kick
                        2 -> 0.92f // Snare
                        else -> 0.88f
                    },
                    pitch = when (padNum) {
                        6 -> 1.15f // Pitch variation for highs
                        7 -> 0.95f
                        8 -> 0.90f
                        else -> 1.0f
                    },
                    reverb = if (category == "Acoustic") 0.15f else if (category == "World") 0.2f else 0.08f,
                    echo = if (i % 5 == 0) 0.25f else 0.0f,
                    autoTrimEnabled = false,
                    trimStartMs = 0,
                    trimThreshold = 0.05f,
                    midiNote = defaultMidiNotes[padNum - 1]
                )
            }
            list.add(
                Patch(
                    patchNumber = i,
                    name = name,
                    category = category,
                    pads = pads
                )
            )
        }
        return list
    }

    private val defaultMidiNotes = listOf(36, 38, 42, 46, 41, 45, 47, 49)

    private fun getPatchMetadata(num: Int): Triple<String, String, List<Pair<String, String>>> {
        val kit = when (num) {
            1 -> Triple(
                "Studio Drum Kit", "Acoustic",
                listOf(
                    "kick_acoustic" to "Acoustic Kick",
                    "snare_crisp" to "Crisp Snare",
                    "hihat_closed" to "Closed Hi-Hat",
                    "hihat_open" to "Open Hi-Hat",
                    "tom_high" to "High Tom",
                    "tom_mid" to "Mid Tom",
                    "tom_low" to "Low Floor Tom",
                    "crash_cymbal" to "Crash Cymbal"
                )
            )
            2 -> Triple(
                "Electronic Dance", "Electronic",
                listOf(
                    "sub_808" to "808 Sub Boom",
                    "snare_crisp" to "Crisp Snare",
                    "hand_clap" to "Hand Clap",
                    "hihat_closed" to "Closed Hi-Hat",
                    "hihat_open" to "Open Hi-Hat",
                    "cowbell" to "Cowbell",
                    "shaker" to "Shaker",
                    "crash_cymbal" to "Crash Cymbal"
                )
            )
            3 -> Triple(
                "Indian Percussion", "World",
                listOf(
                    "dholak_bass" to "Dholak Bass",
                    "dholak_treble" to "Dholak Treble",
                    "tabla_bayan" to "Tabla Bayan",
                    "tabla_dayan" to "Tabla Dayan",
                    "conga_high" to "High Conga",
                    "tambourine" to "Tambourine",
                    "shaker" to "Shaker",
                    "hand_clap" to "Hand Clap"
                )
            )
            4 -> Triple(
                "Latin Carnival", "World",
                listOf(
                    "conga_low" to "Low Conga",
                    "conga_high" to "High Conga",
                    "bongo" to "Bongo Slap",
                    "shaker" to "Shaker",
                    "cowbell" to "Cowbell",
                    "tambourine" to "Tambourine",
                    "rim_shot" to "Rim Shot",
                    "ride_bell" to "Ride Bell"
                )
            )
            5 -> Triple(
                "Rock Stadium", "Acoustic",
                listOf(
                    "kick_acoustic" to "Acoustic Kick",
                    "snare_crisp" to "Crisp Snare",
                    "rim_shot" to "Rim Shot",
                    "hihat_closed" to "Closed Hi-Hat",
                    "tom_high" to "High Tom",
                    "tom_mid" to "Mid Tom",
                    "tom_low" to "Low Floor Tom",
                    "crash_cymbal" to "Crash Cymbal"
                )
            )
            6 -> Triple(
                "808 Trap Master", "Electronic",
                listOf(
                    "sub_808" to "808 Sub Boom",
                    "snare_crisp" to "Crisp Snare",
                    "rim_shot" to "Rim Shot",
                    "hand_clap" to "Hand Clap",
                    "hihat_closed" to "Closed Hi-Hat",
                    "hihat_open" to "Open Hi-Hat",
                    "cowbell" to "Cowbell",
                    "crash_cymbal" to "Crash Cymbal"
                )
            )
            7 -> Triple(
                "Classic Tabla & Dholak", "World",
                listOf(
                    "tabla_bayan" to "Tabla Bayan",
                    "tabla_dayan" to "Tabla Dayan",
                    "dholak_bass" to "Dholak Bass",
                    "dholak_treble" to "Dholak Treble",
                    "tambourine" to "Tambourine",
                    "hand_clap" to "Hand Clap",
                    "shaker" to "Shaker",
                    "ride_bell" to "Ride Bell"
                )
            )
            8 -> Triple(
                "Vintage Funk 70s", "Acoustic",
                listOf(
                    "kick_acoustic" to "Acoustic Kick",
                    "snare_crisp" to "Crisp Snare",
                    "rim_shot" to "Rim Shot",
                    "hihat_closed" to "Closed Hi-Hat",
                    "hihat_open" to "Open Hi-Hat",
                    "cowbell" to "Cowbell",
                    "conga_high" to "High Conga",
                    "ride_bell" to "Ride Bell"
                )
            )
            9 -> Triple(
                "Afrobeat Groove", "World",
                listOf(
                    "kick_acoustic" to "Acoustic Kick",
                    "snare_crisp" to "Crisp Snare",
                    "conga_low" to "Low Conga",
                    "conga_high" to "High Conga",
                    "shaker" to "Shaker",
                    "cowbell" to "Cowbell",
                    "bongo" to "Bongo Slap",
                    "hihat_closed" to "Closed Hi-Hat"
                )
            )
            10 -> Triple(
                "Cyber Techno", "Electronic",
                listOf(
                    "sub_808" to "808 Sub Boom",
                    "snare_crisp" to "Crisp Snare",
                    "hihat_closed" to "Closed Hi-Hat",
                    "hihat_open" to "Open Hi-Hat",
                    "hand_clap" to "Hand Clap",
                    "rim_shot" to "Rim Shot",
                    "ride_bell" to "Ride Bell",
                    "crash_cymbal" to "Crash Cymbal"
                )
            )
            else -> {
                when {
                    num <= 40 -> {
                        val names = listOf(
                            "Jazz Lounge", "Heavy Metal Kit", "Pop Acoustic", "Dry Studio Kit",
                            "Warm Birch", "Maple Custom", "Deep Maple", "R&B Tight",
                            "Gospel Power", "Motown Groove", "Blues Shuffle", "Country Train"
                        )
                        val name = names[(num - 11) % names.size] + " $num"
                        Triple(
                            name, "Acoustic",
                            listOf(
                                "kick_acoustic" to "Acoustic Kick",
                                "snare_crisp" to "Crisp Snare",
                                "hihat_closed" to "Closed Hi-Hat",
                                "hihat_open" to "Open Hi-Hat",
                                "tom_high" to "High Tom",
                                "tom_mid" to "Mid Tom",
                                "tom_low" to "Low Floor Tom",
                                "ride_bell" to "Ride Bell"
                            )
                        )
                    }
                    num <= 80 -> {
                        val names = listOf(
                            "909 Dance Floor", "Electro Wave", "Dubstep Impact", "House Anthem",
                            "Drum & Bass Speed", "Synthwave 84", "Glitch Percussion", "Lo-Fi Beats",
                            "Trap Street", "Hardstyle Core", "Future Bass", "Chill Hop"
                        )
                        val name = names[(num - 41) % names.size] + " $num"
                        Triple(
                            name, "Electronic",
                            listOf(
                                "sub_808" to "808 Sub Boom",
                                "snare_crisp" to "Crisp Snare",
                                "hand_clap" to "Hand Clap",
                                "hihat_closed" to "Closed Hi-Hat",
                                "hihat_open" to "Open Hi-Hat",
                                "cowbell" to "Cowbell",
                                "shaker" to "Shaker",
                                "crash_cymbal" to "Crash Cymbal"
                            )
                        )
                    }
                    num <= 130 -> {
                        val names = listOf(
                            "Samba Carnival", "Bhangra Dhol", "Bongo Club", "Flamenco Cajon",
                            "Reggae Dub", "Bossa Nova", "Oriental Perc", "Middle East Darbuka",
                            "Cuban Rumba", "African Djembe", "Sufi Qawwali", "Carnatic Rhythm"
                        )
                        val name = names[(num - 81) % names.size] + " $num"
                        Triple(
                            name, "World",
                            listOf(
                                "tabla_bayan" to "Tabla Bayan",
                                "tabla_dayan" to "Tabla Dayan",
                                "dholak_bass" to "Dholak Bass",
                                "dholak_treble" to "Dholak Treble",
                                "conga_high" to "High Conga",
                                "bongo" to "Bongo Slap",
                                "shaker" to "Shaker",
                                "tambourine" to "Tambourine"
                            )
                        )
                    }
                    num <= 160 -> {
                        val names = listOf(
                            "Orchestral Timpani", "Marching Snare", "Cinematic Impact", "Taiko Thunder",
                            "Suspense Hit", "Sci-Fi Laser Drum", "Trailer Boom", "Epic War Drums"
                        )
                        val name = names[(num - 131) % names.size] + " $num"
                        Triple(
                            name, "Special",
                            listOf(
                                "tom_low" to "Low Floor Tom",
                                "kick_acoustic" to "Acoustic Kick",
                                "snare_crisp" to "Crisp Snare",
                                "crash_cymbal" to "Crash Cymbal",
                                "ride_bell" to "Ride Bell",
                                "hand_clap" to "Hand Clap",
                                "sub_808" to "808 Sub Boom",
                                "rim_shot" to "Rim Shot"
                            )
                        )
                    }
                    else -> {
                        Triple(
                            "User Custom Kit $num", "User",
                            listOf(
                                "kick_acoustic" to "Acoustic Kick",
                                "snare_crisp" to "Crisp Snare",
                                "hihat_closed" to "Closed Hi-Hat",
                                "hihat_open" to "Open Hi-Hat",
                                "tom_high" to "High Tom",
                                "tom_low" to "Low Floor Tom",
                                "hand_clap" to "Hand Clap",
                                "crash_cymbal" to "Crash Cymbal"
                            )
                        )
                    }
                }
            }
        }
        return kit
    }
}
