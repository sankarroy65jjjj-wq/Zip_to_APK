package com.example.data.local

import com.example.data.model.Patch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext

class PatchRepository(private val patchDao: PatchDao) {

    val allPatches: Flow<List<Patch>> = patchDao.getAllPatches().map { entities ->
        entities.map { it.toDomain() }
    }

    fun getPatch(patchNumber: Int): Flow<Patch?> = patchDao.getPatchByNumber(patchNumber).map { it?.toDomain() }

    suspend fun initializeDefaultPatchesIfNeeded() = withContext(Dispatchers.IO) {
        val count = patchDao.getPatchCount()
        if (count < 200) {
            val all200 = DefaultPatches.createAll200Patches()
            val entities = all200.map { PatchEntity.fromDomain(it) }
            patchDao.insertPatches(entities)
        }
    }

    suspend fun getPatchDirect(patchNumber: Int): Patch? = withContext(Dispatchers.IO) {
        patchDao.getPatchDirect(patchNumber)?.toDomain()
    }

    suspend fun savePatch(patch: Patch) = withContext(Dispatchers.IO) {
        patchDao.updatePatch(PatchEntity.fromDomain(patch))
    }

    suspend fun renamePatch(patchNumber: Int, newName: String) = withContext(Dispatchers.IO) {
        patchDao.renamePatch(patchNumber, newName)
    }
}
