package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface PatchDao {
    @Query("SELECT * FROM patches ORDER BY patchNumber ASC")
    fun getAllPatches(): Flow<List<PatchEntity>>

    @Query("SELECT * FROM patches WHERE patchNumber = :number LIMIT 1")
    fun getPatchByNumber(number: Int): Flow<PatchEntity?>

    @Query("SELECT * FROM patches WHERE patchNumber = :number LIMIT 1")
    suspend fun getPatchDirect(number: Int): PatchEntity?

    @Query("SELECT COUNT(*) FROM patches")
    suspend fun getPatchCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPatches(patches: List<PatchEntity>)

    @Update
    suspend fun updatePatch(patch: PatchEntity)

    @Query("UPDATE patches SET name = :newName WHERE patchNumber = :number")
    suspend fun renamePatch(number: Int, newName: String)
}
