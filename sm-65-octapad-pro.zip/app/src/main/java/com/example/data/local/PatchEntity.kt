package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.data.model.PadConfig
import com.example.data.model.Patch
import org.json.JSONArray
import org.json.JSONObject

@Entity(tableName = "patches")
data class PatchEntity(
    @PrimaryKey
    val patchNumber: Int,
    val name: String,
    val category: String,
    val padsJson: String
) {
    fun toDomain(): Patch {
        val padList = mutableListOf<PadConfig>()
        try {
            val array = JSONArray(padsJson)
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                padList.add(
                    PadConfig(
                        padNumber = obj.optInt("padNumber", i + 1),
                        soundId = obj.optString("soundId", "kick"),
                        soundName = obj.optString("soundName", "Kick"),
                        isCustom = obj.optBoolean("isCustom", false),
                        volume = obj.optDouble("volume", 0.9).toFloat(),
                        pitch = obj.optDouble("pitch", 1.0).toFloat(),
                        reverb = obj.optDouble("reverb", 0.1).toFloat(),
                        echo = obj.optDouble("echo", 0.0).toFloat(),
                        autoTrimEnabled = obj.optBoolean("autoTrimEnabled", false),
                        trimStartMs = obj.optInt("trimStartMs", 0),
                        trimThreshold = obj.optDouble("trimThreshold", 0.05).toFloat(),
                        midiNote = obj.optInt("midiNote", 36 + i)
                    )
                )
            }
        } catch (_: Exception) {
            // Fallback default 8 pads
            for (i in 1..8) {
                padList.add(
                    PadConfig(
                        padNumber = i,
                        soundId = "kick",
                        soundName = "Pad $i",
                        midiNote = 35 + i
                    )
                )
            }
        }
        return Patch(
            patchNumber = patchNumber,
            name = name,
            category = category,
            pads = padList
        )
    }

    companion object {
        fun fromDomain(patch: Patch): PatchEntity {
            val array = JSONArray()
            patch.pads.forEach { pad ->
                val obj = JSONObject().apply {
                    put("padNumber", pad.padNumber)
                    put("soundId", pad.soundId)
                    put("soundName", pad.soundName)
                    put("isCustom", pad.isCustom)
                    put("volume", pad.volume.toDouble())
                    put("pitch", pad.pitch.toDouble())
                    put("reverb", pad.reverb.toDouble())
                    put("echo", pad.echo.toDouble())
                    put("autoTrimEnabled", pad.autoTrimEnabled)
                    put("trimStartMs", pad.trimStartMs)
                    put("trimThreshold", pad.trimThreshold.toDouble())
                    put("midiNote", pad.midiNote)
                }
                array.put(obj)
            }
            return PatchEntity(
                patchNumber = patch.patchNumber,
                name = patch.name,
                category = patch.category,
                padsJson = array.toString()
            )
        }
    }
}
