package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.DefaultPatches
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("SM 65 OCTAPAD PRO", appName)
    }

    @Test
    fun `verify 200 default patches generated with 8 pads each`() {
        val patches = DefaultPatches.createAll200Patches()
        assertEquals(200, patches.size)
        patches.forEach { patch ->
            assertEquals(8, patch.pads.size)
            assertNotNull(patch.name)
            assertNotNull(patch.category)
        }
    }
}
