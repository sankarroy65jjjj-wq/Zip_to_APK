# SM 65 OCTAPAD PRO — Android APK build notes

This is a native Android Gradle/Kotlin project. To build a debug APK, the build server must have Android SDK (API 36 / extension level 1 as configured by the project), a compatible JDK, and Gradle.

## Codemagic
1. Push the *contents* of this project to a GitHub repository (not the ZIP itself).
2. Add the repository in Codemagic.
3. Commit this `codemagic.yaml` file at the repository root.
4. Start the `android-debug-apk` workflow. If successful, download the APK from the build's Artifacts section.

## Important Gradle Wrapper note
The uploaded ZIP contains `gradle/wrapper/gradle-wrapper.properties` but does not contain `gradle-wrapper.jar`, `gradlew`, or `gradlew.bat`. This environment cannot fetch the official wrapper binary, so it has not been fabricated. The workflow uses a preinstalled `gradle` command if available; otherwise it stops with a clear error. For a fully portable project, generate the official wrapper using an installed Gradle distribution and commit all three files:

- `gradlew`
- `gradlew.bat`
- `gradle/wrapper/gradle-wrapper.jar`

The existing `gradle/wrapper/gradle-wrapper.properties` specifies Gradle 9.3.1. Use that version when generating the wrapper, and verify the JAR is from the official Gradle distribution.

No real `.env` secrets or signing keystore have been added. Debug builds use the project's configured debug signing settings. A release APK may require separate signing configuration.
